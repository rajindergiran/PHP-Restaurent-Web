<?php
    // database values
    $dblocation = "localhost";
    $dbname = "oose";
    $dbuser = "root";
    $dbpass = "";
?>